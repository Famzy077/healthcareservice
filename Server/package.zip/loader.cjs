const loadApp = async() => {
    await import('./Api/index.js')
}
loadApp()