const loadApp = async() => {
    await import('./index.js')
}
loadApp()